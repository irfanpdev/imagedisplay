from django.contrib import admin
from .models import ImageUploads

   
# Register your models here.
admin.site.register(ImageUploads)
